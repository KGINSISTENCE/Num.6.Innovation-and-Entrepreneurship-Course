#ifndef Blink_h
#define Blink_h

#include <Arduino.h>

#define ON true
#define OFF false

class Blink
{
  public:
  Blink(int pin);
  void blink(int brightness,int blinkLength,int blinkLoops);

  private:
  uint8_t pinNumber;
};

#endif

