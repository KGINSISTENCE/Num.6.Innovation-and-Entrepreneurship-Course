#include <Arduino.h>
#include "blink.h"

Blink::Blink(int pin){
pinMode(pin, OUTPUT);
pinNumber = pin; 
}

void Blink::blink(int brightness, int blinkLength, int blinkLoops){

for(int i=0;i<blinkLoops;i++){
for(int a=0;a<=brightness;a++){
	analogWrite(pinNumber,a);
	delay(blinkLength);
}
for(int a=0;a<=brightness;a--){
	analogWrite(pinNumber,a);
	delay(blinkLength);
}
}
}
